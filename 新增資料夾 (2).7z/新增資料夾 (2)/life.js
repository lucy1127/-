

function life(){
	
	document.getElementById("manu").style.display = "block";
}
function lifeclose(){
	
	document.getElementById("manu").style.display = "none";
}